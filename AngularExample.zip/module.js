/**
 * Created by Bartłomiej on 2014-08-25.
 */
angular.module('AngularExample', ['ngRoute']);